
#include "item.h"

using namespace std;

Item::Item(int id): _id(id) {
    
}

int Item::getid() const{
    return _id;
}

